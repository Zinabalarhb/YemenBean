﻿namespace YemenBean.Core
{
    public class Class1
    {

    }
}
