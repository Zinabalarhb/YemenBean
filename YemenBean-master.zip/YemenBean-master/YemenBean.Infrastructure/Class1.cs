﻿namespace YemenBean.Infrastructure
{
    public class Class1
    {

    }
}
