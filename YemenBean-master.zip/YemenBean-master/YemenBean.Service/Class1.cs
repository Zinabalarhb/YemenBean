﻿namespace YemenBean.Service
{
    public class Class1
    {

    }
}
